module.exports = Collection;

/**
 * Конструктор коллекции
 * @constructor
 */
function Collection() {}


// Методы коллекции
Collection.prototype.values = function () {};
// другие методы


/**
 * Создание коллекции из массива значений
 */
Collection.from = function () {};
